// Yamen BEN GUIRAT et Enzo Tulissi, Prog C //

// 01/11/23 //





#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>

int lecture_dossier(char *);

void lecture_dossier_recursif(char *);

void lecture_dossier_iteratif(char *);

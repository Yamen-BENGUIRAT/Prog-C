// Yamen BEN GUIRAT et Enzo Tulissi, Prog C //

// 01/11/23 //



int addition(int,int);

int soustraction(int , int );

int produit(int , int ); 

int quotient(int , int );

int modulo(int , int );    

int ET(int , int );    

int OU(int , int );
    
int negation(int , int );
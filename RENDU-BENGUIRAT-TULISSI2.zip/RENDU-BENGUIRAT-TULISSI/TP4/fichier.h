// Yamen BEN GUIRAT et Enzo Tulissi, Prog C //

// 01/11/23 //



// Declaration des fonctions
char lire_fichier(char *nom_fichier); 

char ecrire_dans_fichier(char *nom_fichier,  char *message );

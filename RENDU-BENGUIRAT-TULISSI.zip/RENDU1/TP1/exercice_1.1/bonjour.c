/*
Yamen BEN GUIRAT et Enzo TULISSI.
20/09/23
Programme qui consiste à afficher du texte.
*/


#include <stdio.h>// headers

int main() {
    printf("Bonjour le Monde!");
    return 0;
}
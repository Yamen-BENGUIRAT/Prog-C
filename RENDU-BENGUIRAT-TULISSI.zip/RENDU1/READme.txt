BEN GUIRAT Yamen
TULISSI Enzo


RENDU TP 1-3 PROGRAMMATION C 



L'objectif des 3 premiers TP est de commencer à se familiariser 
avce les notions de base de la programmation en C. Nous avons donc
appris comment afficher du texte ou des nombres, effectuer des 
calculs, crées des fonctions, mit en places des boucles, des conditions...
Ainsi,ces premiers TP nous ont été utiles pour se familiariser avec l'outil, 
et ainsi pouvoir comprendre les différents concepts et pouvoir travailler sur des 
projets plus complexes à l'avenir.
Nous allons donc voir en quoi ces exercices nous ont été utiles en sachant que leurs 
fonctionnalités sont décrites en commmentaires.

TP 1

bonjour.c
-Affichage de texte.
-Initialisation d'un programme en C.


cercle.c
-Initialisation à la déclaration de variable.
-Initialisation au calcul C.
-Initialisation à l'interaction machine/humain.


sizeof_types.c
-Initialisation détemrmination taille des type de bases.
-Initialisation au types de bases.


variables.c
-Initialisation aux variabeles signed et unsigned.


opérateurs.c
-Initialisation aux calculs via opérateurs.


boucles.c
-Initialisation aux boucles for + conditions.


conditions.c
-Association des notions vu précédemment.


opérateurs2.c
-Initialisation aux conditions en utilisant des switch case.


binaire.c
-Initialisation de la conversion decimal/bits.






TP 2


bits.c
-Travail sur exraction de bits et verification de résultat.


chaîne.c
-Initialisation boucle while.
-Initialisation création de fonctions.


couleurs.c
-Utilisation de la notation hexadécimale d'un nombre.
-Utilisation format RGBA couleur.


etudiant.c
-Initialisation création de tableaux.
-Stockage d'informations dans un tableau.


etudiant2.c
-Stockage informations avec saisie utilisateur dans un tableau.


fibonacci.c
-Utilisation de boucles.
-Calcul de termes.


puissance.c
-Réalisation d'un calcul sans Utilisation d'une librairie.


tableauptr.c
-Réalisation de multiples opérations au sein d'un tableau.


variables.c
-Manipulaton des variables via les pointeurs.




TP 3



chercher.c
-Generation de nombres dans un tableau en utilisant une horloge.
-Utilisation tableaux.


chercher2.c
-Détemrmination de la présence d'une phrase avec fgets.
-Utilisation tableaux de chaînes de caractères.


couleur_compteur.c
-Initialisation utilisation de structures.
-Parcours de tableau


grand_petit.c
-Parcours de tableaux d'entiers.
-Comparaison des différents nombres et détermination du plus grand et plus
petit nombre.


octets.c
-Affichage des tailles en octets des différents types de données en
utilisant les opérations de pointeurs.


recherche_dichotomoique.c
-Création de fonctions.
-Utilisation de conditions ( while, if..).


sizeof.c
-Détermination des différentes tailles en octets des différents types
de données.


tri.c
-Initialisation tri à bulles.
-Utilisation fonctions et tableaux.












